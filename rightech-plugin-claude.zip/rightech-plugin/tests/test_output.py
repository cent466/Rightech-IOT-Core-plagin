"""Тесты сборки готовых файлов для импорта. Сеть не используется."""

from __future__ import annotations

import contextlib
import datetime as dt
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path

PLUGIN_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PLUGIN_ROOT / "scripts"))

import make_import_file as builder  # noqa: E402

SAMPLES = PLUGIN_ROOT / "references" / "samples"
MOMENT = dt.datetime(2026, 11, 14, 12, 0, tzinfo=dt.timezone.utc)


def sample(*parts: str) -> tuple[str, dict]:
    raw = json.loads(SAMPLES.joinpath(*parts).read_text(encoding="utf-8-sig"))
    return raw["store"], raw["data"]


class EnvelopeTests(unittest.TestCase):
    def test_envelope_shape_and_service_fields_removed(self):
        _, entity = sample("primer_model", "2026-11-14_Модель_Умный_дом.json")
        envelope = builder.build_envelope("models", entity, origin="dev.rightech.io", moment=MOMENT)
        self.assertEqual(list(envelope), ["version", "origin", "time", "store", "data"])
        self.assertEqual(envelope["version"], 1)
        self.assertEqual(envelope["origin"], "dev.rightech.io")
        self.assertEqual(envelope["time"], "2026-11-14T12:00:00.000Z")
        self.assertEqual(envelope["store"], "models")
        self.assertNotIn("_id", envelope["data"])
        self.assertNotIn("owner", envelope["data"])
        self.assertNotIn("group", envelope["data"])
        self.assertEqual(envelope["data"]["name"], entity["name"])
        self.assertEqual(envelope["data"]["base"], entity["base"])

    def test_model_nodes_have_no_platform_fields(self):
        _, entity = sample("primer_model", "2026-11-14_Модель_Термометр_«Автон»_A845___A845-50___A855___A855-50_NB-IoT_(NIDD).json")
        envelope = builder.build_envelope("models", entity, moment=MOMENT)
        text = json.dumps(envelope["data"])
        for key in builder.NODE_SERVICE_FIELDS:
            self.assertNotIn(f'"{key}"', text)

    def test_scenario_data_stays_string(self):
        _, entity = sample("primer_scena", "2026-11-14_Сценарий_day_night.json")
        envelope = builder.build_envelope("automatons", entity, moment=MOMENT)
        self.assertIsInstance(envelope["data"]["data"], str)
        self.assertIn("states", json.loads(envelope["data"]["data"]))


class NamingTests(unittest.TestCase):
    def test_filename_matches_platform_style(self):
        name = "Термометр «Автон» A845 / A855"
        filename = builder.output_filename("models", name, MOMENT)
        self.assertTrue(filename.startswith("2026-11-14_Модель_"))
        self.assertTrue(filename.endswith(".json"))
        self.assertNotIn("/", filename)
        self.assertNotIn('"', filename)

    def test_labels_for_each_type(self):
        for store, label in builder.TYPE_LABELS.items():
            self.assertIn(label, builder.output_filename(store, "Имя", MOMENT))

    def test_empty_name_gets_placeholder(self):
        self.assertIn("без_имени", builder.output_filename("models", "   ", MOMENT))

    def test_unsafe_characters_replaced(self):
        cleaned = builder.safe_name('a\\b:c*d?e"f<g>h|i')
        for char in '\\:*?"<>|':
            self.assertNotIn(char, cleaned)


class WriteTests(unittest.TestCase):
    def test_model_writes_one_json(self):
        _, entity = sample("primer_model", "2026-11-14_Модель_Термометр_«Автон»_A845___A845-50___A855___A855-50_NB-IoT_(NIDD).json")
        with tempfile.TemporaryDirectory() as tmp:
            written = builder.write_files("models", entity, Path(tmp))
            self.assertEqual(len(written), 1)
            payload = json.loads(written[0].read_text(encoding="utf-8"))
            self.assertEqual(payload["store"], "models")
            self.assertNotIn("_id", payload["data"])

    def test_handler_writes_json_and_javascript(self):
        _, entity = sample("primer_obrabotka", "2026-11-14_Обработчик_AQWA_control.json")
        with tempfile.TemporaryDirectory() as tmp:
            written = builder.write_files("handlers", entity, Path(tmp))
            self.assertEqual(len(written), 2)
            extensions = sorted(path.suffix for path in written)
            self.assertEqual(extensions, [".js", ".json"])
            code = next(path for path in written if path.suffix == ".js")
            self.assertIn("export function process", code.read_text(encoding="utf-8"))

    def test_handler_typescript_gets_ts_file(self):
        _, entity = sample("primer_obrabotka", "2026-11-14_Обработчик_Датчик_положения_«Автон»_NB-Iot.json")
        with tempfile.TemporaryDirectory() as tmp:
            written = builder.write_files("handlers", entity, Path(tmp))
            self.assertIn(".ts", [path.suffix for path in written])


class CliTests(unittest.TestCase):
    def test_builds_file_from_export(self):
        path = SAMPLES / "primer_geo" / "2026-11-14_Геозона_Ленинградская_область.json"
        with tempfile.TemporaryDirectory() as tmp:
            with contextlib.redirect_stdout(io.StringIO()):
                code = builder.main([str(path), "--out-dir", tmp])
            self.assertEqual(code, 0)
            files = list(Path(tmp).glob("*.json"))
            self.assertEqual(len(files), 1)
            payload = json.loads(files[0].read_text(encoding="utf-8"))
            self.assertEqual(payload["store"], "geofences")
            self.assertEqual(len(payload["data"]["shape"]["points"]), 7)

    def test_invalid_entity_is_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "broken.json"
            source.write_text(json.dumps({"base": "mqtt", "data": {"id": "root"}}), encoding="utf-8")
            out = Path(tmp) / "out"
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                code = builder.main([str(source), "--store", "models", "--out-dir", str(out)])
            self.assertEqual(code, 1)
            self.assertFalse(out.exists())

    def test_detects_store_without_hint(self):
        entity = {"userCode": "export function process() { return {}; }", "language": "javascript", "name": "h"}
        self.assertEqual(builder.detect_store(entity), "handlers")


if __name__ == "__main__":
    unittest.main(verbosity=2)
