"""Тесты офлайн-валидатора: рабочие образцы проходят, некорректные данные отклоняются."""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

PLUGIN_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PLUGIN_ROOT / "scripts"))

import validate  # noqa: E402


MODULE_BLOCK = {
    "id": "external-software-modules",
    "name": "Внешние программные модули",
    "active": True,
    "copy": True,
    "type": "subsystem",
    "children": [],
    "_inactive": False,
}


def model(base: str = "mqtt", nodes: list[dict] | None = None) -> dict:
    return {
        "name": "test_model",
        "base": base,
        "description": "Test model",
        "data": {
            "id": "root",
            "type": "subsystem",
            "name": "test_model",
            "active": True,
            "_inactive": False,
            "children": [dict(MODULE_BLOCK)]
            + (
                nodes
                if nodes is not None
                else [
                    {
                        "id": "temperature",
                        "name": "Temperature",
                        "type": "argument",
                        "active": True,
                        "source": "state",
                        "dataType": "number",
                        "reference": "temperature",
                        "unit": "temperature-celsius",
                        "_inactive": False,
                    }
                ]
            ),
        },
    }


def scene(states: dict | None = None, transitions: dict | None = None) -> dict:
    states = states or {
        "0": {"data": {"type": "init", "id": "0", "width": 20, "height": 20}},
        "1": {"data": {"type": "final", "id": "1", "width": 20, "height": 20}},
    }
    transitions = transitions or {
        "0": {
            "data": {
                "id": "0",
                "event": "init",
                "owner": {"id": "0"},
                "target": {"id": "1"},
            }
        }
    }
    return {
        "name": "Test scenario",
        "description": "",
        "model": "66654ad6d45ee1790071c208",
        "models": ["66654ad6d45ee1790071c208"],
        "data": json.dumps({"states": states, "transitions": transitions}),
    }


def geofence(points: list[list[float]] | None = None) -> dict:
    return {
        "name": "Test zone",
        "color": "#2986FF",
        "style": {"fillOpacity": 0.2, "opacity": 0.75, "weight": 2},
        "shape": {"type": "polygon", "points": points or [[55.1, 41.1], [55.2, 41.2], [55.3, 41.1]]},
        "floors": [],
        "props": {},
    }


def handler(code: str | None = None) -> dict:
    return {
        "name": "Test handler",
        "language": "javascript",
        "userCode": code
        if code is not None
        else "export function process(payload) {\n  return { value: JSON.parse(payload).value };\n}\n",
        "props": {"setUndefinedParamTo": "prev"},
        "parameters": {"m-66654ad6d45ee1790071c208": {"h-6662973dd45ee17900719840": {"import": {"payload": "model.payload"}}}},
    }


class SampleTests(unittest.TestCase):
    def test_all_working_samples_pass_without_remarks(self) -> None:
        samples = sorted((PLUGIN_ROOT / "references" / "samples").rglob("*.json"))
        self.assertEqual(len(samples), 25, "ожидается 25 образцов")
        problems: list[str] = []
        for path in samples:
            store, entity = validate.load_entity(path, None)
            report = validate.validate_entity(store, entity, "export")
            if report.errors or report.warnings:
                problems.append(f"{path.name}: {report.errors} {report.warnings}")
        self.assertEqual(problems, [], "\n".join(problems))


class ModelTests(unittest.TestCase):
    def test_valid_model(self) -> None:
        report = validate.validate_entity("models", model(), "new")
        self.assertEqual(report.errors, [])

    def test_missing_name_and_base(self) -> None:
        entity = model()
        entity.pop("name")
        entity.pop("base")
        report = validate.validate_entity("models", entity, "new")
        self.assertTrue(any("name" in error for error in report.errors))
        self.assertTrue(any("base" in error for error in report.errors))

    def test_duplicate_node_ids(self) -> None:
        nodes = [
            {"id": "a", "name": "A", "type": "argument", "active": True, "dataType": "number"},
            {"id": "a", "name": "B", "type": "argument", "active": True, "dataType": "number"},
        ]
        report = validate.validate_entity("models", model(nodes=nodes), "new")
        self.assertTrue(any("повторяющийся id" in error for error in report.errors))

    def test_unknown_node_type_and_data_type(self) -> None:
        nodes = [{"id": "a", "name": "A", "type": "teleport", "active": True}]
        report = validate.validate_entity("models", model(nodes=nodes), "new")
        self.assertTrue(any("неизвестный type" in error for error in report.errors))

        nodes = [{"id": "a", "name": "A", "type": "argument", "active": True, "dataType": "float"}]
        report = validate.validate_entity("models", model(nodes=nodes), "new")
        self.assertTrue(any("dataType" in error for error in report.errors))

    def test_missing_module_block_is_error_for_new_model(self) -> None:
        entity = model()
        entity["data"]["children"] = entity["data"]["children"][1:]
        report = validate.validate_entity("models", entity, "new")
        self.assertTrue(any("external-software-modules" in error for error in report.errors))

    def test_module_block_needs_copy_true(self) -> None:
        entity = model()
        entity["data"]["children"][0].pop("copy")
        report = validate.validate_entity("models", entity, "new")
        self.assertTrue(any("copy=true" in warning for warning in report.warnings))

    def test_new_model_naming_and_template_warnings(self) -> None:
        nodes = [
            {
                "id": "Pump-State",
                "name": "Pump state",
                "type": "argument",
                "active": True,
                "dataType": "boolean",
            }
        ]
        report = validate.validate_entity("models", model(nodes=nodes), "new")
        texts = " ".join(report.warnings)
        self.assertIn("snake_case", texts)
        self.assertIn("_inactive", texts)
        self.assertIn("source", texts)
        self.assertIn("reference", texts)

    def test_external_block_is_not_policed_for_snake_case(self) -> None:
        report = validate.validate_entity("models", model(), "new")
        self.assertFalse(any("snake_case" in warning for warning in report.warnings))

    def test_envelope_version_must_be_one(self) -> None:
        payload = {
            "version": 2,
            "origin": "dev.rightech.io",
            "store": "models",
            "data": model(),
        }
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "broken-envelope.json"
            path.write_text(json.dumps(payload), encoding="utf-8")
            report = validate.Report()
            validate.load_entity(path, None, report)
        self.assertTrue(any("version" in error for error in report.errors))

    def test_service_fields_rejected_in_new_mode(self) -> None:
        entity = model()
        entity["_id"] = "66654ad6d45ee1790071c208"
        entity["owner"] = "65dc8b32d164fb3fdc0fd843"
        report = validate.validate_entity("models", entity, "new")
        self.assertTrue(any("служебные поля" in error for error in report.errors))
        export_report = validate.validate_entity("models", entity, "export")
        self.assertEqual(export_report.errors, [])


class ScenarioTests(unittest.TestCase):
    def test_valid_scenario(self) -> None:
        report = validate.validate_entity("automatons", scene(), "new")
        self.assertEqual(report.errors, [])

    def test_data_must_be_encoded_string(self) -> None:
        entity = scene()
        entity["data"] = json.loads(entity["data"])
        report = validate.validate_entity("automatons", entity, "new")
        self.assertTrue(any("строкой" in error for error in report.errors))

    def test_broken_inner_json(self) -> None:
        entity = scene()
        entity["data"] = "{not json"
        report = validate.validate_entity("automatons", entity, "new")
        self.assertTrue(any("не разбирается" in error for error in report.errors))

    def test_transition_must_reference_existing_state(self) -> None:
        transitions = {
            "0": {"data": {"id": "0", "event": "init", "owner": {"id": "0"}, "target": {"id": "missing"}}}
        }
        report = validate.validate_entity("automatons", scene(transitions=transitions), "new")
        self.assertTrue(any("отсутствует в states" in error for error in report.errors))

    def test_transition_without_event(self) -> None:
        transitions = {"0": {"data": {"id": "0", "owner": {"id": "0"}, "target": {"id": "1"}}}}
        report = validate.validate_entity("automatons", scene(transitions=transitions), "new")
        self.assertTrue(any("нет event" in error for error in report.errors))


class GeofenceTests(unittest.TestCase):
    def test_valid_geofence(self) -> None:
        report = validate.validate_entity("geofences", geofence(), "new")
        self.assertEqual(report.errors, [])

    def test_open_ring_is_allowed(self) -> None:
        points = [[55.1, 41.1], [55.2, 41.2], [55.3, 41.1]]
        self.assertNotEqual(points[0], points[-1])
        report = validate.validate_entity("geofences", geofence(points=points), "new")
        self.assertEqual(report.errors, [])

    def test_coordinates_out_of_range(self) -> None:
        report = validate.validate_entity("geofences", geofence(points=[[95.0, 41.1], [55.2, 41.2], [55.3, 41.1]]), "new")
        self.assertTrue(any("широта" in error for error in report.errors))

    def test_circle_requires_reference(self) -> None:
        entity = geofence()
        entity["shape"] = {"type": "circle", "center": [55.1, 41.1], "radius": 100}
        report = validate.validate_entity("geofences", entity, "new")
        self.assertTrue(any("polygon" in error for error in report.errors))


class HandlerTests(unittest.TestCase):
    def test_valid_handler(self) -> None:
        report = validate.validate_entity("handlers", handler(), "new")
        self.assertEqual(report.errors, [])

    def test_missing_entry_point(self) -> None:
        report = validate.validate_entity("handlers", handler("const x = 1;"), "new")
        self.assertTrue(any("export function process" in error for error in report.errors))

    def test_secret_in_code(self) -> None:
        # токен собран из частей, чтобы в репозитории не лежала строка, похожая на настоящий JWT
        fake_jwt = "eyJ" + "hbGciOiJIUzI1NiJ9" + "." + "eyJzdWIiOiIxMjM0NTY3ODkwIn0" + "." + "dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
        code = f"export function process(payload) {{\n  const token = '{fake_jwt}';\n  return {{}};\n}}\n"
        report = validate.validate_entity("handlers", handler(code), "new")
        self.assertTrue(any("секрет" in error for error in report.errors))

    def test_unbalanced_braces(self) -> None:
        report = validate.validate_entity("handlers", handler("export function process(payload) {"), "new")
        self.assertTrue(any("синтаксическая проблема" in error for error in report.errors))

    def test_braces_inside_strings_are_ignored(self) -> None:
        code = 'export function process(payload) {\n  const tpl = "}{";\n  const re = /[}]/;\n  return { value: tpl };\n}\n'
        report = validate.validate_entity("handlers", handler(code), "new")
        self.assertEqual(report.errors, [])

    def test_unknown_language(self) -> None:
        entity = handler()
        entity["language"] = "python"
        report = validate.validate_entity("handlers", entity, "new")
        self.assertTrue(any("language" in error for error in report.errors))


class CommonTests(unittest.TestCase):
    def test_unknown_store(self) -> None:
        report = validate.validate_entity("widgets", {"name": "x"}, "new")
        self.assertTrue(any("неизвестный тип" in error for error in report.errors))

    def test_raw_json_requires_store_hint(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "bare.json"
            path.write_text(json.dumps(geofence()), encoding="utf-8")
            with self.assertRaises(ValueError):
                validate.load_entity(path, None)
            store, entity = validate.load_entity(path, "geofences")
            self.assertEqual(store, "geofences")
            self.assertEqual(entity["name"], "Test zone")


if __name__ == "__main__":
    unittest.main(verbosity=2)
